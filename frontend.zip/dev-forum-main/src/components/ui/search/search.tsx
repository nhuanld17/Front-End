type SearchProps = {};

export const Search = () => {
    
}