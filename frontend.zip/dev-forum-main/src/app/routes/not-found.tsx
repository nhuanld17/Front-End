export const NotFoundRoute = () => {
    return <div>NotFound</div>;
};
