export const SocialLinkRoute = () => {
    return (
        <div>
            <h1>Social Link</h1>
        </div>
    )
}