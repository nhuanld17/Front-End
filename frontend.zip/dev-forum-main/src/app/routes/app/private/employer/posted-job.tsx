import { JobCreatingForm } from "src/features/home/components/employer/job-creating-form"


export const PostedJobRoute = () => {

    return (
        <JobCreatingForm />        
    )
}