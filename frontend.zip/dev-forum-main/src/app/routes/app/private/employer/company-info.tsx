export const CompanyInfoRoute = () => {
    return (
        <div>
            <h1>Company Info</h1>
        </div>
    )
};