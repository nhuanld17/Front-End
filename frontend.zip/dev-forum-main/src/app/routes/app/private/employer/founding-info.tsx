export const FoundingInfoRoute = () => {
    return (
        <div>
            <h1>Founding Info</h1>
        </div>
    )
}