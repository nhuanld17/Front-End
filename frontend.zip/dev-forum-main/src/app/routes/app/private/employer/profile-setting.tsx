export const ProfileSettingRoute = () => {
    return (
        <div>
            <h1>Profile Setting</h1>
        </div>
    )
}