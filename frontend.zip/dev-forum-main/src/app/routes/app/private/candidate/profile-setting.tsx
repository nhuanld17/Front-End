import { ProfileForm } from "src/features/home/components/candidate/profile-form"

export const ProfileSettingRoute = () => {
    return (
        <div>
            <ProfileForm />
        </div>
    )
}