import { SocialLinkForm } from "src/features/home/components/candidate/social-link-form"

export const SocialLinkRoute = () => {
    return (
        <div>
            <SocialLinkForm />
        </div>
    )
}