import { AccountSettingForm } from "src/features/home/components/candidate/account-setting-form"

export const AccountSettingRoute = () => {
    return (
        <div>
            <AccountSettingForm />
        </div>
    )
}