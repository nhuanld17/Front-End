import { ForgotPasswordForm } from "src/features/auth";

export const ForgotPasswordRoute = () => {
    return <ForgotPasswordForm />;
};