import { RegisterForm } from "src/features/auth";

export const RegisterRoute = () => {
    return (
        <RegisterForm />
    );
}