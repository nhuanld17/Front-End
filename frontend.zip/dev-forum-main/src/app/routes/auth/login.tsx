import { LoginForm } from "src/features/auth";

export const LoginRoute = () => {
    return <LoginForm />;
};