export const OtpRoute = () => {
    return <div>Otp</div>;
};