import login_banner from './login-banner.png';
import coder_image from './coder-image.png';
import static_icon_1 from './static-icon-1.png';
import static_icon_2 from './static-icon-2.png';
import static_icon_3 from './static-icon-3.png';
import static_icon_4 from './static-icon-4.png';
import banner from './banner.png';
import upload_picture from './upload_picture.png';


export {
    login_banner, 
    coder_image, 
    static_icon_1, 
    static_icon_2,
    static_icon_3,
    static_icon_4,
    banner,
    upload_picture
};