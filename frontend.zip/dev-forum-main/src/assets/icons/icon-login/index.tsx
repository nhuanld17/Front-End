import fi_eye from './fi_eye.svg?react';
import fi_arrow_right from './fi_arrow-right.svg?react';
import google from './google.svg?react';
import facebook from './facebook.svg?react';
import buildings_duotone from './buildings-duotone.svg?react';
import briefcase_duotone from './briefcase-duotone.svg?react';
import briefcaseblue from './briefcaseblue.svg?react';
import successful from "./successful.svg?react";

export {
    fi_eye,
    fi_arrow_right,
    google,
    facebook,
    buildings_duotone,
    briefcase_duotone,
    briefcaseblue,
    successful
}